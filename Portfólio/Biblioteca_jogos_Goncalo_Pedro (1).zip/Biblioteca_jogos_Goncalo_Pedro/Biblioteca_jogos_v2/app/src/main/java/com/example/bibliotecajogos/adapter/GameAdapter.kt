package com.example.bibliotecajogos.adapter


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.bibliotecajogos.R
import com.example.bibliotecajogos.database.Game
import android.widget.ImageView
import com.bumptech.glide.Glide


class GameAdapter(
    private val onDeleteClick: (Game) -> Unit,
    private val onItemClick: (Game) -> Unit
) :
    RecyclerView.Adapter<GameAdapter.GameViewHolder>() {


    private var games = emptyList<Game>()


    class GameViewHolder(
        itemView: View
    ) :
        RecyclerView.ViewHolder(itemView) {

        val image: ImageView = itemView.findViewById(R.id.gameImage)
        val name: TextView = itemView.findViewById(R.id.gameName)
        val platform: TextView = itemView.findViewById(R.id.gamePlatform)
        val genre: TextView = itemView.findViewById(R.id.gameGenre)
        val rating: TextView = itemView.findViewById(R.id.gameRating)
        val deleteButton: Button = itemView.findViewById(R.id.deleteButton)

    }


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): GameViewHolder {

        val view =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.item_game, parent, false)

        return GameViewHolder(view)

    }


    override fun onBindViewHolder(
        holder: GameViewHolder,
        position: Int
    ) {

        val current = games[position]

        holder.name.text = current.name
        holder.platform.text = "Plataforma: ${current.platform}"
        holder.genre.text = "Género: ${current.genre}"
        holder.rating.text = "Nota: ${current.rating}"

        if (current.imageUri.isNotEmpty()) {

            Glide.with(holder.itemView.context)
                .load(current.imageUri)
                .into(holder.image)

        } else {

            holder.image.setImageResource(R.drawable.ic_launcher_foreground)

        }

        holder.deleteButton.setOnClickListener {
            onDeleteClick(current)
        }

        holder.itemView.setOnClickListener {
            onItemClick(current)
        }

    }


    override fun getItemCount(): Int {
        return games.size
    }


    fun setGames(games: List<Game>) {
        this.games = games
        notifyDataSetChanged()
    }

}
