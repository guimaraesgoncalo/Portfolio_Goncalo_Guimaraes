package com.example.bibliotecajogos.activities

import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.bibliotecajogos.database.Game
import com.example.bibliotecajogos.databinding.ActivityAddGameBinding
import com.example.bibliotecajogos.viewmodel.GameViewModel
import com.example.bibliotecajogos.viewmodel.GameViewModelFactory


class AddGameActivity : AppCompatActivity() {


    private lateinit var binding: ActivityAddGameBinding
    private var selectedImageUri: String = ""

    private val imagePicker =
        registerForActivityResult(
            ActivityResultContracts.GetContent()
        ) { uri ->

            if (uri != null) {

                selectedImageUri = uri.toString()

                binding.gameImagePreview.setImageURI(uri)

            }

        }

    private val viewModel: GameViewModel by viewModels {

        GameViewModelFactory(application)

    }


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = ActivityAddGameBinding.inflate(layoutInflater)

        setContentView(binding.root)


        binding.selectImageButton.setOnClickListener {

            imagePicker.launch("image/*")

        }

        binding.saveButton.setOnClickListener {

            val name = binding.nameInput.text.toString().trim()

            if (name.isEmpty()) {
                binding.nameInput.error = "Insere o nome do jogo"
                return@setOnClickListener
            }

            val game = Game(
                name = name,
                platform = binding.platformInput.text.toString(),
                genre = binding.genreInput.text.toString(),
                rating = binding.ratingInput.text.toString().toDoubleOrNull() ?: 0.0,
                imageUri = selectedImageUri
            )

            viewModel.insert(game)

            finish()

        }

    }

}
