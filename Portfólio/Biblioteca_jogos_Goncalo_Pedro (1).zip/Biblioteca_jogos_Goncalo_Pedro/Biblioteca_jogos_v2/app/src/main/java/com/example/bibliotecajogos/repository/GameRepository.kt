package com.example.bibliotecajogos.repository

import androidx.lifecycle.LiveData
import com.example.bibliotecajogos.database.Game
import com.example.bibliotecajogos.database.GameDao

class GameRepository(
    private val gameDao: GameDao
) {

    val allGames: LiveData<List<Game>> =
        gameDao.getAllGames()


    suspend fun insert(game: Game) {
        gameDao.insert(game)
    }


    suspend fun update(game: Game) {
        gameDao.update(game)
    }


    suspend fun delete(game: Game) {
        gameDao.delete(game)
    }


    fun search(query: String): LiveData<List<Game>> {
        return gameDao.searchGames(query)
    }


    suspend fun getGameById(id: Int): Game? {
        return gameDao.getGameById(id)
    }
}