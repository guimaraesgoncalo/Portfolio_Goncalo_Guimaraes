package com.example.bibliotecajogos.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.example.bibliotecajogos.database.Game
import com.example.bibliotecajogos.database.GameDatabase
import com.example.bibliotecajogos.repository.GameRepository
import kotlinx.coroutines.launch


class GameViewModel(
    application: Application
) : AndroidViewModel(application) {


    private val repository: GameRepository


    val allGames: LiveData<List<Game>>


    init {

        val dao =
            GameDatabase
                .getDatabase(application)
                .gameDao()

        repository =
            GameRepository(dao)

        allGames =
            repository.allGames
    }


    fun insert(game: Game) {

        viewModelScope.launch {

            repository.insert(game)

        }
    }


    fun update(game: Game) {

        viewModelScope.launch {

            repository.update(game)

        }
    }


    fun delete(game: Game) {

        viewModelScope.launch {

            repository.delete(game)

        }
    }


    fun search(query:String): LiveData<List<Game>> {

        return repository.search(query)

    }


    fun getGameById(id: Int) =
        liveData {

            emit(
                repository.getGameById(id)
            )

        }
}