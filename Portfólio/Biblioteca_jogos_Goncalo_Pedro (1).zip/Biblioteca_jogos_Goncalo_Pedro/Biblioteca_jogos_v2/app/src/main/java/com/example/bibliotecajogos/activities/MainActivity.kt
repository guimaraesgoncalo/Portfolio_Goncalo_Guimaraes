package com.example.bibliotecajogos.activities

import android.content.Intent
import android.text.Editable
import android.text.TextWatcher
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.bibliotecajogos.adapter.GameAdapter
import com.example.bibliotecajogos.databinding.ActivityMainBinding
import com.example.bibliotecajogos.viewmodel.GameViewModel
import com.example.bibliotecajogos.viewmodel.GameViewModelFactory


class MainActivity : AppCompatActivity() {


    private lateinit var binding: ActivityMainBinding


    private val viewModel: GameViewModel by viewModels {
        GameViewModelFactory(application)
    }


    private val adapter =
        GameAdapter(

            onDeleteClick = { game ->

                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("Eliminar jogo")
                    .setMessage("Queres eliminar ${game.name}?")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Apagar") { _, _ ->
                        viewModel.delete(game)
                    }
                    .show()

            },

            onItemClick = { game ->

                val intent = Intent(this, EditGameActivity::class.java)
                intent.putExtra("GAME_ID", game.id)
                startActivity(intent)

            }

        )


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.recyclerViewGames.adapter = adapter

        binding.recyclerViewGames.layoutManager = LinearLayoutManager(this)

        binding.recyclerViewGames.addItemDecoration(
            androidx.recyclerview.widget.DividerItemDecoration(
                this,
                androidx.recyclerview.widget.DividerItemDecoration.VERTICAL
            )
        )

        viewModel.allGames.observe(this) { games ->
            adapter.setGames(games)
        }

        binding.addButton.setOnClickListener {
            startActivity(Intent(this, AddGameActivity::class.java))
        }

        binding.searchEditText.addTextChangedListener(

            object : TextWatcher {

                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

                    val query = s.toString()

                    viewModel.search(query).observe(this@MainActivity) { games ->
                        adapter.setGames(games)
                    }

                }

                override fun afterTextChanged(s: Editable?) {}

            }

        )

    }

}
