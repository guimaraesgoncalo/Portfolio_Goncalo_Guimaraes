package com.example.bibliotecajogos.activities

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.bibliotecajogos.database.Game
import com.example.bibliotecajogos.databinding.ActivityEditGameBinding
import com.example.bibliotecajogos.viewmodel.GameViewModel
import com.example.bibliotecajogos.viewmodel.GameViewModelFactory


class EditGameActivity : AppCompatActivity() {


    private lateinit var binding: ActivityEditGameBinding

    private val viewModel: GameViewModel by viewModels {
        GameViewModelFactory(application)
    }

    private var gameId = 0

    private var currentGame: Game? = null


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = ActivityEditGameBinding.inflate(layoutInflater)

        setContentView(binding.root)

        gameId = intent.getIntExtra("GAME_ID", 0)

        viewModel.getGameById(gameId).observe(this) { game ->

            if (game != null) {

                currentGame = game

                binding.nameInput.setText(game.name)

                binding.platformInput.setText(game.platform)

                binding.genreInput.setText(game.genre)

                binding.ratingInput.setText(game.rating.toString())

            }

        }

        binding.saveButton.setOnClickListener {

            val updatedGame = Game(
                id = gameId,
                name = binding.nameInput.text.toString(),
                platform = binding.platformInput.text.toString(),
                genre = binding.genreInput.text.toString(),
                rating = binding.ratingInput.text.toString().toDoubleOrNull() ?: 0.0,
                imageUri = currentGame?.imageUri ?: ""
            )

            viewModel.update(updatedGame)

            finish()

        }

    }

}
