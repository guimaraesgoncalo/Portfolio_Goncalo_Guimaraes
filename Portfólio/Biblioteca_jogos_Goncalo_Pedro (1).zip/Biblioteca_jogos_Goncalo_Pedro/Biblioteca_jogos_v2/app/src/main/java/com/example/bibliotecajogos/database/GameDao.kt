package com.example.bibliotecajogos.database

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface GameDao {

    @Insert
    suspend fun insert(game: Game)

    @Update
    suspend fun update(game: Game)

    @Delete
    suspend fun delete(game: Game)

    @Query("SELECT * FROM games ORDER BY rating DESC")
    fun getAllGames(): LiveData<List<Game>>

    @Query("SELECT * FROM games WHERE id = :id")
    suspend fun getGameById(id: Int): Game?

    @Query("""
SELECT * FROM games
WHERE name LIKE '%' || :query || '%'
OR platform LIKE '%' || :query || '%'
OR genre LIKE '%' || :query || '%'
ORDER BY rating DESC
""")
    fun searchGames(query: String): LiveData<List<Game>>
}