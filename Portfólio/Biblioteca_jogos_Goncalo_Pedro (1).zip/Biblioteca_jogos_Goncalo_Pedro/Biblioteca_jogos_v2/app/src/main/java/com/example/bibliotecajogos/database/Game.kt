package com.example.bibliotecajogos.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "games")
data class Game(

    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val name: String,

    val platform: String,

    val genre: String,

    val rating: Double,

    val imageUri: String = ""
)
