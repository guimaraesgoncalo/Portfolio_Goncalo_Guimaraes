 <footer class="bg-light text-center text-lg-start mt-auto py-4 border-top">
        <div class="container">
            <p class="mb-0">&copy; {{ date('Y') }} {{ config('app.name', 'GestorDoc') }}. Todos os direitos
                reservados.</p>
        </div>
    </footer>
