 <nav class="navbar navbar-expand-lg navbar-light bg-light">
     <div class="container">
         <a class="navbar-brand" href="/">{{ config('app.name', 'GestorDoc') }}</a>
         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
             aria-controls="navbarNav" aria-expanded="false" aria-label="Alternar navegação">
             <span class="navbar-toggler-icon"></span>
         </button>

         <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
             <ul class="navbar-nav">
                 @if (Route::has('login'))
                     @auth
                         <li class="nav-item">
                             <a class="nav-link" href="{{ url('/dashboard') }}">Painel</a>
                         </li>

                         <li class="nav-item">
                             <a class="nav-link" href="{{ route('categories.index') }}">Categorias</a>
                         </li>
                         <li class="nav-item">
                             <a class="nav-link" href="{{ route('documents.index') }}">Documentos</a>
                         </li>
                         <li class="nav-item">
                             <a class="nav-link" href="{{ route('tags.index') }}">Tags</a>
                         </li>
                     @else
                         <li class="nav-item">
                             <a class="nav-link" href="{{ route('login') }}">Iniciar sessão</a>
                         </li>
                         @if (Route::has('register'))
                             <li class="nav-item">
                                 <a class="nav-link" href="{{ route('register') }}">Registar</a>
                             </li>
                         @endif

                     @endauth
                 @endif

             </ul>
         </div>
     </div>
 </nav>
