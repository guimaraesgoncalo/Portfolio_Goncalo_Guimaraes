@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card shadow-sm text-center">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">Dashboard</h3>
                </div>

                <div class="card-body py-5">

                    <h1 class="mb-4">
                        Olá, {{ Auth::user()->name }}
                    </h1>

                    <p class="text-muted mb-4">
                        Welcome back to your account.
                    </p>

                    <form method="POST" action="/logout">
                        @csrf

                        <button
                            type="submit"
                            class="btn btn-danger px-4"
                        >
                            Logout
                        </button>
                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

@endsection
