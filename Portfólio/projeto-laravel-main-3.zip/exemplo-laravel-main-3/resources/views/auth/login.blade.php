@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">

            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white text-center">
                    <h3 class="mb-0">Login</h3>
                </div>

                <div class="card-body p-4">

                    <form method="POST" action="/login">
                        @csrf

                        {{-- Email --}}
                        <div class="mb-3">
                            <label class="form-label">Email</label>

                            <input
                                name="email"
                                type="email"
                                placeholder="Enter your email"
                                class="form-control"
                                required
                            >
                        </div>

                        {{-- Password --}}
                        <div class="mb-4">
                            <label class="form-label">Password</label>

                            <input
                                name="password"
                                type="password"
                                placeholder="Enter your password"
                                class="form-control"
                                required
                            >
                        </div>

                        {{-- Submit Button --}}
                        <div class="d-grid">
                            <button
                                type="submit"
                                class="btn btn-primary"
                            >
                                Login
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
@endsection
