<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>{{ config('app.name', 'Laravel') }} - Gestor de Documentos</title>

    <!-- Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>

<body class="d-flex flex-column min-vh-100">

    <!-- Navbar -->
   <x-navbar/>

    <!-- Main content -->
    <main class="container my-5 flex-grow-1">
        <div class="text-center mb-5">
            <h1 class="display-4">Bem-vindo ao {{ config('app.name', 'GestorDoc') }}</h1>
            <p class="lead">O seu gestor de documentos seguro e eficiente. Organize, partilhe e aceda aos seus
                ficheiros em qualquer lugar.</p>
            <a href="#" class="btn btn-primary btn-lg">Começar</a>
        </div>

        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Armazenamento Seguro</h5>
                        <p class="card-text">Guarde todos os seus documentos de forma segura com encriptação de ponta a
                            ponta.</p>
                        <a href="#" class="btn btn-outline-primary">Saber mais</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Partilha Simplificada</h5>
                        <p class="card-text">Partilhe ficheiros e pastas com colegas ou clientes de forma rápida e
                            controlada.</p>
                        <a href="#" class="btn btn-outline-primary">Saber mais</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Acesso em Qualquer Lugar</h5>
                        <p class="card-text">Aceda aos seus documentos a partir de qualquer dispositivo, a qualquer
                            hora, sem complicações.</p>
                        <a href="#" class="btn btn-outline-primary">Saber mais</a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
   <x-footer/>
    <!-- Bootstrap 5 JS Bundle CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kQmPH5j5GqZ86Vd1s4yZ0cw8vB1R3v8PqgGhjf+gC6sRZbgywCjNswG7z4eBp9RZ" crossorigin="anonymous">
    </script>
</body>

</html>
