@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Lista de Documentos</h1>
    <a href="{{ route('documents.create') }}" class="btn btn-success">
        + Criar Novo Documento
    </a>
</div>

@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Categoria</th>
                <th>Tags</th> {{-- ✅ NEW --}}
                <th>Descrição</th>
                <th>Ficheiro</th>
                <th>Ações</th>
            </tr>
        </thead>

        <tbody>
            @forelse ($documents as $document)
                <tr>
                    <td>{{ $document->id }}</td>

                    <td>{{ $document->name }}</td>

                    <td>
                        {{ $document->category->name ?? '—' }}
                    </td>

                    {{-- ✅ Tags --}}
                    <td>
                        @forelse ($document->tags as $tag)
                            <span class="badge bg-primary">
                                {{ $tag->name }}
                            </span>
                        @empty
                            <span class="text-muted">—</span>
                        @endforelse
                    </td>

                    <td>{{ $document->description ?? '—' }}</td>

                    <td>
                        @if ($document->file_path)
                            <a href="{{ asset('storage/' . $document->file_path) }}"
                               target="_blank"
                               class="btn btn-link btn-sm">
                                Ver
                            </a>
                        @else
                            —
                        @endif
                    </td>

                    <td>
                        <a href="{{ route('documents.show', $document) }}"
                           class="btn btn-info btn-sm">
                            Ver
                        </a>

                        <a href="{{ route('documents.edit', $document) }}"
                           class="btn btn-primary btn-sm">
                            Editar
                        </a>

                        <form action="{{ route('documents.destroy', $document) }}"
                              method="POST"
                              class="d-inline">
                            @csrf
                            @method('DELETE')

                            <button type="submit"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Tens a certeza?')">
                                Apagar
                            </button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="7" class="text-center text-muted">
                        Não existem documentos.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-3">
    {{ $documents->links() }}
</div>

@endsection
