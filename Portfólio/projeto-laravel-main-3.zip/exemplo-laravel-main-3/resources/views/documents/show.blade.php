@extends('layouts.app')

@section('content')
    <a href="{{ route('documents.index') }}" class="btn btn-secondary me-2">
        ← Voltar ao index
    </a>

    <a href="{{ route('documents.edit', $document) }}" class="btn btn-primary">
        Editar
    </a>

    <h1 class="my-4">Detalhes do Documento</h1>

    <ul class="list-group mb-4">
        <li class="list-group-item">
            <strong>ID:</strong> {{ $document->id }}
        </li>

        <li class="list-group-item">
            <strong>Nome:</strong> {{ $document->name }}
        </li>

        <li class="list-group-item">
            <strong>Categoria:</strong>
            <span class="badge bg-secondary">
                {{ $document->category->name ?? 'Sem categoria' }}
            </span>
        </li>

        <li class="list-group-item">
            <strong>Descrição:</strong> {{ $document->description ?? '—' }}
        </li>

        {{-- ✅ Tags --}}
        <li class="list-group-item">
            <strong>Tags:</strong><br>

            @forelse ($document->tags as $tag)
                <span class="badge bg-primary me-1">
                    {{ $tag->name }}
                </span>
            @empty
                <span class="text-muted">Sem tags</span>
            @endforelse
        </li>

        <li class="list-group-item">
            <strong>Criado em:</strong>
            {{ $document->created_at->format('d/m/Y H:i') }}
        </li>

        <li class="list-group-item">
            <strong>Atualizado em:</strong>
            {{ $document->updated_at->format('d/m/Y H:i') }}
        </li>
    </ul>

    <div class="mb-4">
        <strong>Ficheiro:</strong><br>

        @if ($document->file_path)
            <a href="{{ asset('storage/' . $document->file_path) }}" target="_blank" class="btn btn-link">
                Ver / Download
            </a>
        @else
            <p class="text-muted">Sem ficheiro associado</p>
        @endif
    </div>

    <div>
        <form action="{{ route('documents.destroy', $document) }}" method="POST"
            onsubmit="return confirm('Tens a certeza que queres apagar este documento?')">
            @csrf
            @method('DELETE')

            <button type="submit" class="btn btn-danger">
                Apagar
            </button>
        </form>
    </div>
@endsection
