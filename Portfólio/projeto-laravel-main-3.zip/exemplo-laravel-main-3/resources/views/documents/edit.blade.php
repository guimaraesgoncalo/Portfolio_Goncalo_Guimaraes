@extends('layouts.app')

@section('content')

<a href="{{ route('documents.index') }}" class="btn btn-secondary mb-3">
    <- Voltar ao index
</a>

<h1 class="mb-4">Editar Documento</h1>

@if ($errors->any())
    <div class="alert alert-danger">
        <ul class="mb-0">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('documents.update', $document) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')

    <!-- Name -->
    <div class="mb-3">
        <label for="name" class="form-label">Nome:</label>
        <input
            type="text"
            id="name"
            name="name"
            value="{{ old('name', $document->name) }}"
            class="form-control"
            required
        >
    </div>

    <!-- Description -->
    <div class="mb-3">
        <label for="description" class="form-label">Descrição:</label>
        <textarea
            id="description"
            name="description"
            rows="4"
            class="form-control"
        >{{ old('description', $document->description) }}</textarea>
    </div>

    <!-- Category -->
    <div class="mb-3">
        <label for="category_id" class="form-label">Categoria:</label>
        <select id="category_id" name="category_id" class="form-select" required>
            <option value="">-- Selecionar Categoria --</option>
            @foreach ($categories as $id => $name)
                <option value="{{ $id }}"
                    {{ old('category_id', $document->category_id) == $id ? 'selected' : '' }}>
                    {{ $name }}
                </option>
            @endforeach
        </select>
    </div>

    <!-- Tags (many-to-many) -->
    <div class="mb-3">
        <label for="tags" class="form-label">Tags:</label>

        <select id="tags" name="tags[]" class="form-select" multiple>
            @foreach ($tags as $tag)
                <option value="{{ $tag->id }}"
                    {{ collect(old('tags', $document->tags->pluck('id')->toArray()))
                        ->contains($tag->id) ? 'selected' : '' }}>
                    {{ $tag->name }}
                </option>
            @endforeach
        </select>

        <small class="text-muted">Pode selecionar várias tags.</small>
    </div>

    <!-- Current file -->
    <div class="mb-3">
        <label class="form-label">Ficheiro atual:</label><br>

        @if ($document->file_path)
            <a href="{{ asset('storage/' . $document->file_path) }}"
               target="_blank"
               class="btn btn-link">
                Ver ficheiro atual
            </a>
        @else
            <p class="text-muted">Sem ficheiro</p>
        @endif
    </div>

    <!-- Upload new file -->
    <div class="mb-3">
        <label for="file_path" class="form-label">Alterar ficheiro:</label>
        <input
            type="file"
            id="file_path"
            name="file_path"
            accept=".pdf,.doc,.docx,.png,.jpg"
            class="form-control"
        >
    </div>

    <button type="submit" class="btn btn-primary">
        Atualizar
    </button>
</form>

@endsection
