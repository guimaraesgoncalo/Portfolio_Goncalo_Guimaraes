@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">User Profile</h3>
                </div>

                <div class="card-body">

                    <div class="mb-3">
                        <label class="fw-bold">Name</label>
                        <p class="form-control-plaintext">
                            {{ $user->name }}
                        </p>
                    </div>

                    <div class="mb-4">
                        <label class="fw-bold">Email</label>
                        <p class="form-control-plaintext">
                            {{ $user->email }}
                        </p>
                    </div>

                    <a
                        href="{{ route('profile.edit') }}"
                        class="btn btn-primary"
                    >
                        Edit Profile
                    </a>

                </div>
            </div>

        </div>
    </div>
</div>
@endsection
