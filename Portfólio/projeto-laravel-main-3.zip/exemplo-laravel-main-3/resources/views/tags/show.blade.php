@extends('layouts.app')

@section('content')

<a href="{{ route('tags.index') }}" class="btn btn-secondary me-2">
    Voltar ao index
</a>

<a href="{{ route('tags.edit', $tag) }}" class="btn btn-primary">
    Editar
</a>

<h1 class="my-4">Detalhes da Tag</h1>

<ul class="list-group mb-4">
    <li class="list-group-item">
        <strong>ID:</strong> {{ $tag->id }}
    </li>

    <li class="list-group-item">
        <strong>Nome:</strong> {{ $tag->name }}
    </li>

    <li class="list-group-item">
        <strong>Slug:</strong> <code>{{ $tag->slug }}</code>
    </li>

    <li class="list-group-item">
        <strong>Criado em:</strong>
        {{ $tag->created_at->format('d/m/Y H:i') }}
    </li>

    <li class="list-group-item">
        <strong>Atualizado em:</strong>
        {{ $tag->updated_at->format('d/m/Y H:i') }}
    </li>
</ul>

<div>
    <form action="{{ route('tags.destroy', $tag) }}" method="POST"
        onsubmit="return confirm('Tens a certeza que queres apagar esta tag?')">
        @csrf
        @method('DELETE')

        <button type="submit" class="btn btn-danger">
             Apagar
        </button>
    </form>
</div>

@endsection
