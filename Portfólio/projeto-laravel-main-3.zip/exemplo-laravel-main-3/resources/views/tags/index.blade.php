@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Tags</h1>
    <a href="{{ route('tags.create') }}" class="btn btn-success">
        + Nova Tag
    </a>
</div>

@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Slug</th>
                <th>Ações</th>
            </tr>
        </thead>

        <tbody>
            @forelse ($tags as $tag)
                <tr>
                    <td>{{ $tag->id }}</td>

                    <td>
                        <a href="{{ route('tags.show', $tag) }}">
                            {{ $tag->name }}
                        </a>
                    </td>

                    <td>
                        <code>{{ $tag->slug }}</code>
                    </td>

                    <td>
                        <a href="{{ route('tags.show', $tag) }}"
                           class="btn btn-info btn-sm">
                            Ver
                        </a>

                        <a href="{{ route('tags.edit', $tag) }}"
                           class="btn btn-primary btn-sm">
                            Editar
                        </a>

                        <form action="{{ route('tags.destroy', $tag) }}"
                              method="POST"
                              class="d-inline">
                            @csrf
                            @method('DELETE')

                            <button type="submit"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Tens a certeza?')">
                                Apagar
                            </button>
                        </form>
                    </td>
                </tr>

            @empty
                <tr>
                    <td colspan="4" class="text-center text-muted">
                        Não existem tags.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

@endsection
