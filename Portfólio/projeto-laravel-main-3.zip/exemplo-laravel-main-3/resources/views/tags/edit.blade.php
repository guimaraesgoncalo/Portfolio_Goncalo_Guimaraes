@extends('layouts.app')

@section('content')

<a href="{{ route('tags.index') }}" class="btn btn-secondary mb-3">
    ← Voltar ao index
</a>

<h1 class="mb-4">Editar Tag</h1>

@if ($errors->any())
    <div class="alert alert-danger">
        <ul class="mb-0">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('tags.update', $tag) }}" method="POST">
    @csrf
    @method('PUT')

    <div class="mb-3">
        <label for="name" class="form-label">Nome:</label>
        <input
            type="text"
            id="name"
            name="name"
            value="{{ old('name', $tag->name) }}"
            class="form-control"
            required
        >
    </div>

    <div class="mb-3">
        <label for="slug" class="form-label">Slug:</label>
        <input
            type="text"
            id="slug"
            name="slug"
            value="{{ old('slug', $tag->slug) }}"
            class="form-control"
        >
        <small class="text-muted">Identificador URL da tag</small>
    </div>

    <button type="submit" class="btn btn-primary">Atualizar Tag</button>
</form>

@endsection
