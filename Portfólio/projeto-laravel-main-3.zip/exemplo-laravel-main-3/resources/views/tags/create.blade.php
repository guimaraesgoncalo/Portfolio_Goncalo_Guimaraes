@extends('layouts.app')

@section('content')

<a href="{{ route('tags.index') }}" class="btn btn-secondary mb-3">
    <- Voltar ao index
</a>

<h1 class="mb-4">Criar Nova Tag</h1>

@if ($errors->any())
    <div class="alert alert-danger">
        <ul class="mb-0">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ route('tags.store') }}" method="POST">
    @csrf

    <div class="mb-3">
        <label for="name" class="form-label">Nome:</label>
        <input
            type="text"
            id="name"
            name="name"
            value="{{ old('name') }}"
            class="form-control"
            required
        >
    </div>

    <div class="mb-3">
        <label for="slug" class="form-label">Slug:</label>
        <input
            type="text"
            id="slug"
            name="slug"
            value="{{ old('slug') }}"
            class="form-control"
            placeholder="ex: laravel-tips"
        >
        <small class="text-muted">Opcional — pode ser gerado automaticamente.</small>
    </div>

    <button type="submit" class="btn btn-primary">Criar Tag</button>
</form>

@endsection
