<!-- Template de Detalhes do Documento para alunos completarem -->

<!-- Botões de navegação -->
<a href="<!-- URL do index de documentos -->" class="btn btn-secondary me-2">← Voltar ao index</a>
<a href="<!-- URL para editar este documento -->" class="btn btn-primary">Editar</a>

<h1 class="my-4">Detalhes do Documento</h1>

<ul class="list-group mb-4">
    <li class="list-group-item"><strong>ID:</strong> <!-- ID do documento --></li>
    <li class="list-group-item"><strong>Nome:</strong> <!-- Nome do documento --></li>
    <li class="list-group-item"><strong>Descrição:</strong> <!-- Descrição do documento ou "—" se vazio --></li>
    <li class="list-group-item"><strong>Criado em:</strong> <!-- Data de criação formatada --></li>
    <li class="list-group-item"><strong>Atualizado em:</strong> <!-- Data de atualização formatada --></li>
</ul>

<div class="mb-4">
    <strong>Ficheiro:</strong><br>
    <!-- Se existir ficheiro -->
    <a href="<!-- URL do ficheiro -->" target="_blank" class="btn btn-link">
        Ver / Download
    </a>
    <!-- Senão -->
    <p class="text-muted">Sem ficheiro associado</p>
</div>

<div>
    <!-- Formulário para apagar documento -->
    <form action="<!-- URL para apagar documento -->" method="POST" onsubmit="return confirm('Tens a certeza que queres apagar este documento?')">
        <!-- Inserir CSRF se necessário -->
        <!-- Método DELETE se necessário -->
        <button type="submit" class="btn btn-danger">
            🗑️ Apagar
        </button>
    </form>
</div>
