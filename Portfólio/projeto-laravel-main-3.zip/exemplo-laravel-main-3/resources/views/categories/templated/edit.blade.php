<!-- Template de Edição de Documento para os alunos completarem -->

<!-- Link para voltar ao index dos documents -->
<a href="<!-- URL do index de documentos -->" class="btn btn-secondary mb-3">← Voltar ao index</a>

<h1 class="mb-4">Editar Documento</h1>

<!-- Exibir erros de validação -->
<div class="alert alert-danger" style="display: none;">
    <ul class="mb-0">
        <!-- Para cada erro, criar um <li> -->
        <!-- <li>Erro de exemplo</li> -->
    </ul>
</div>

<!-- Formulário de edição -->
<form action="<!-- URL para atualizar documento -->" method="POST" enctype="multipart/form-data">
    <!-- Inserir CSRF se necessário -->
    <!-- Inserir método PUT se necessário -->

    <div class="mb-3">
        <label for="name" class="form-label">Nome:</label>
        <input
            type="text"
            id="name"
            name="name"
            value="<!-- Valor atual ou antigo do nome -->"
            class="form-control"
            required
        >
    </div>

    <div class="mb-3">
        <label for="description" class="form-label">Descrição:</label>
        <textarea
            id="description"
            name="description"
            rows="4"
            class="form-control"
        ><!-- Valor atual ou antigo da descrição --></textarea>
    </div>

    <div class="mb-3">
        <label class="form-label">Ficheiro atual:</label><br>
        <!-- Se existir ficheiro atual -->
        <a href="<!-- URL do ficheiro atual -->" target="_blank" class="btn btn-link">
            Ver ficheiro atual
        </a>
        <!-- Senão -->
        <p class="text-muted">Sem ficheiro</p>
    </div>

    <div class="mb-3">
        <label for="file_path" class="form-label">Alterar ficheiro:</label>
        <input
            type="file"
            id="file_path"
            name="file_path"
            accept=".pdf,.doc,.docx,.png,.jpg"
            class="form-control"
        >
    </div>

    <button type="submit" class="btn btn-primary">Atualizar</button>
</form>
