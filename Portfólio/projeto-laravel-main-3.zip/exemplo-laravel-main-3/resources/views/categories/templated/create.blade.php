<!-- Template de Criação de Documento para os alunos completarem -->

<!-- Link para voltar ao index dos documents -->
<a href="<!-- URL do index de documentos -->" class="btn btn-secondary mb-3">← Voltar ao index</a>

<h1 class="mb-4">Criar Novo Documento</h1>

<!-- Exibir erros de validação -->
<div class="alert alert-danger" style="display: none;">
    <ul class="mb-0">
        <!-- Para cada erro, criar um <li> -->
        <!-- <li>Erro de exemplo</li> -->
    </ul>
</div>

<!-- Formulário de criação -->
<form action="<!-- URL para criar documento -->" method="POST" enctype="multipart/form-data">
    <!-- Inserir CSRF se necessário -->

    <div class="mb-3">
        <label for="name" class="form-label">Nome:</label>
        <input
            type="text"
            id="name"
            name="name"
            value="<!-- Valor antigo se houver -->"
            class="form-control"
            required
        >
    </div>

    <div class="mb-3">
        <label for="description" class="form-label">Descrição:</label>
        <textarea
            id="description"
            name="description"
            rows="4"
            class="form-control"
        ><!-- Valor antigo se houver --></textarea>
    </div>

    <div class="mb-3">
        <label for="file_path" class="form-label">Ficheiro:</label>
        <input
            type="file"
            id="file_path"
            name="file_path"
            class="form-control"
            required
        >
    </div>

    <button type="submit" class="btn btn-primary">Criar</button>
</form>
