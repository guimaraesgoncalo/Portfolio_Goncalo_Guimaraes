
<!-- Coloque aqui a ligação ao layout principal (se necessário) -->

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Lista de Documentos</h1>
    <!-- Link para criar um novo documento -->
    <a href="<!-- URL para criar documento -->" class="btn btn-success">+ Criar Novo Documento</a>
</div>

<!-- Mensagem de sucesso -->
<!-- Inserir aqui uma condição para mostrar mensagem de sucesso -->
<div class="alert alert-success" style="display: none;">
    <!-- Mensagem de sucesso -->
</div>

<div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Ficheiro</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop para listar os documentos -->
            <!-- Para cada documento, criar uma linha <tr> -->
            <!-- Exemplo de linha -->
            <tr>
                <td><!-- ID do documento --></td>
                <td><!-- Nome do documento --></td>
                <td><!-- Descrição do documento ou "—" se vazio --></td>
                <td>
                    <!-- Se existir ficheiro, colocar link para ver -->
                    <a href="<!-- URL do ficheiro -->" target="_blank" class="btn btn-link btn-sm">Ver</a>
                    <!-- Senão, mostrar "—" -->
                </td>
                <td>
                    <!-- Botões de ações -->
                    <a href="<!-- URL para ver documento -->" class="btn btn-info btn-sm">Ver</a>
                    <a href="<!-- URL para editar documento -->" class="btn btn-primary btn-sm">Editar</a>

                    <!-- Formulário para apagar documento -->
                    <form action="<!-- URL para apagar documento -->" method="POST" class="d-inline">
                        <!-- Inserir CSRF se necessário -->
                        <!-- Método DELETE -->
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Tens a certeza?')">
                            Apagar
                        </button>
                    </form>
                </td>
            </tr>

            <!-- Caso não existam documentos -->
            <tr>
                <td colspan="5" class="text-center text-muted">Não existem documentos.</td>
            </tr>

        </tbody>
    </table>
</div>
