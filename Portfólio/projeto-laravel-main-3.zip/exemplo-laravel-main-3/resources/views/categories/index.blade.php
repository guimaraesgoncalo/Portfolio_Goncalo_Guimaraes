@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Categorias</h1>
    <a href="{{ route('categories.create') }}" class="btn btn-success">
        + Nova Categoria
    </a>
</div>

@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Slug</th>
                <th>Descrição</th>
                <th>Documentos</th> <!-- NEW -->
                <th>Ações</th>
            </tr>
        </thead>

        <tbody>
            @forelse ($categories as $category)
                <tr>
                    <td>{{ $category->id }}</td>

                    <td>
                        <a href="{{ route('categories.show', $category) }}">
                            {{ $category->name }}
                        </a>
                    </td>

                    <td>
                        <code>{{ $category->slug }}</code>
                    </td>

                    <td>
                        {{ $category->description ?? '—' }}
                    </td>

                    <!-- Document count -->
                    <td>
                        <span class="badge bg-primary">
                            {{ $category->documents_count ?? $category->documents->count() }}
                        </span>
                    </td>

                    <td>
                        <a href="{{ route('categories.show', $category) }}"
                           class="btn btn-info btn-sm">
                            Ver
                        </a>

                        <a href="{{ route('categories.edit', $category) }}"
                           class="btn btn-primary btn-sm">
                            Editar
                        </a>

                        <form action="{{ route('categories.destroy', $category) }}"
                              method="POST"
                              class="d-inline">
                            @csrf
                            @method('DELETE')

                            <button type="submit"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Tens a certeza?')">
                                Apagar
                            </button>
                        </form>
                    </td>
                </tr>

            @empty
                <tr>
                    <td colspan="6" class="text-center text-muted">
                        Não existem categorias.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

@endsection
