@extends('layouts.app')

@section('content')

    <a href="{{ route('categories.index') }}" class="btn btn-secondary me-2">
     Voltar ao index
    </a>

    <a href="{{ route('categories.edit', $category) }}" class="btn btn-primary">
        Editar
    </a>

    <h1 class="my-4">Detalhes da Categoria</h1>

    <ul class="list-group mb-4">
        <li class="list-group-item">
            <strong>ID:</strong> {{ $category->id }}
        </li>

        <li class="list-group-item">
            <strong>Nome:</strong> {{ $category->name }}
        </li>

        <li class="list-group-item">
            <strong>Slug:</strong> <code>{{ $category->slug }}</code>
        </li>

        <li class="list-group-item">
            <strong>Descrição:</strong> {{ $category->description ?? '—' }}
        </li>

        <li class="list-group-item">
            <strong>Criado em:</strong>
            {{ $category->created_at->format('d/m/Y H:i') }}
        </li>

        <li class="list-group-item">
            <strong>Atualizado em:</strong>
            {{ $category->updated_at->format('d/m/Y H:i') }}
        </li>
    </ul>

    <div class="mb-4">
        <h4>Documentos nesta categoria</h4>

        @if ($category->documents->count())
            <ul class="list-group">
                @foreach ($category->documents as $document)
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span>{{ $document->name }}</span>

                        <a href="{{ route('documents.show', $document) }}" class="btn btn-sm btn-info">
                            Ver
                        </a>
                    </li>
                @endforeach
            </ul>
        @else
            <p class="text-muted">Nenhum documento associado.</p>
        @endif
    </div>

    <div>
        <form action="{{ route('categories.destroy', $category) }}" method="POST"
            onsubmit="return confirm('Tens a certeza que queres apagar esta categoria?')">
            @csrf
            @method('DELETE')

            <button type="submit" class="btn btn-danger">
                🗑️ Apagar
            </button>
        </form>
    </div>

@endsection
