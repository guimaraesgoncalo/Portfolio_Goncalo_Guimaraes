<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreDocumentRequest;
use App\Http\Requests\UpdateDocumentRequest;
use App\Models\Category;
use App\Models\Document;
use App\Models\Tag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DocumentController extends Controller
{
    public function __construct()
    {
        // Automatically applies DocumentPolicy to all resource methods
        $this->authorizeResource(Document::class, 'document');
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $documents = $request->user()
            ->documents()
            ->with(['category', 'tags'])
            ->latest()
            ->paginate(10);

        return view('documents.index', compact('documents'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::pluck('name', 'id');
        $tags = Tag::all();

        return view('documents.create', compact('categories', 'tags'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDocumentRequest $request)
    {
        $data = $request->validated();

        // Handle file upload
        if ($request->hasFile('file_path')) {
            $data['file_path'] = $request->file('file_path')
                ->store('documents', 'public');
        }

        // Ownership handled here (no observer needed)
        $document = $request->user()
            ->documents()
            ->create($data);

        // Attach tags (many-to-many)
        $document->tags()->sync($request->tags ?? []);

        return redirect()
            ->route('documents.show', $document)
            ->with('success', 'Document created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Document $document)
    {
        $document->load(['category', 'tags']);

        return view('documents.show', compact('document'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Document $document)
    {
        $categories = Category::pluck('name', 'id');
        $tags = Tag::all();

        $document->load('tags');

        return view('documents.edit', compact('document', 'categories', 'tags'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDocumentRequest $request, Document $document)
    {
        $data = $request->validated();

        // Handle file replacement
        if ($request->hasFile('file_path')) {
            if (
                $document->file_path &&
                Storage::disk('public')->exists($document->file_path)
            ) {
                Storage::disk('public')->delete($document->file_path);
            }

            $data['file_path'] = $request->file('file_path')
                ->store('documents', 'public');
        }

        $document->update($data);

        // Sync tags (many-to-many)
        $document->tags()->sync($request->tags ?? []);

        return redirect()
            ->route('documents.show', $document)
            ->with('success', 'Document updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Document $document)
    {
        // Delete file if exists
        if (
            $document->file_path &&
            Storage::disk('public')->exists($document->file_path)
        ) {
            Storage::disk('public')->delete($document->file_path);
        }

        // detach tags automatically via cascade on pivot (optional but clean)
        $document->tags()->detach();

        $document->delete();

        return redirect()
            ->route('documents.index')
            ->with('success', 'Document deleted successfully.');
    }
}
