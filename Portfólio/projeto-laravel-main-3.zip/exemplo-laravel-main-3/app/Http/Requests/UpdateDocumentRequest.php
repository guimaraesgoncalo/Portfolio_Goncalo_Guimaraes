<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateDocumentRequest extends FormRequest
{
    /**
     * Allow request (later restrict via policies if needed)
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Validation rules
     */
    public function rules(): array
    {
        return [
            'name' => ['sometimes', 'required', 'string', 'max:255'],

            'description' => ['nullable', 'string'],

            // category update support
            'category_id' => ['sometimes', 'required', 'exists:categories,id'],

            // file replacement
            'file_path' => ['sometimes', 'file', 'max:10240'],

            'tags' => ['sometimes', 'array'],
            'tags.*' => ['integer', 'exists:tags,id'],
        ];
    }
}
