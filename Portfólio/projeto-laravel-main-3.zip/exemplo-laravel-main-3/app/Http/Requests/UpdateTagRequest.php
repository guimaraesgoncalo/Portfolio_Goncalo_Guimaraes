<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateTagRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
       $tag = $this->route('tag');

    return [
        'name' => [
            'required',
            'string',
            'max:255',
            Rule::unique('tags', 'name')->ignore($tag),
        ],

        'slug' => [
            'nullable',
            'string',
            'max:255',
            Rule::unique('tags', 'slug')->ignore($tag),
        ],
    ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'O campo nome é obrigatório.',
            'name.string' => 'O campo nome deve ser uma string.',
            'name.max' => 'O campo nome não pode ter mais de 255 caracteres.',
            'name.unique' => 'Já existe uma tag com este nome.',

            'slug.string' => 'O campo slug deve ser uma string.',
            'slug.max' => 'O campo slug não pode ter mais de 255 caracteres.',
            'slug.unique' => 'Já existe uma tag com este slug.',
        ];
    }
}
