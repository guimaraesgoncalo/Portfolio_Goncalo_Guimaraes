<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreDocumentRequest extends FormRequest
{
    /**
     * Allow request (you can restrict later with policies)
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Validation rules
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],

            'description' => ['nullable', 'string'],

            // category relationship
            'category_id' => ['required', 'exists:categories,id'],

            // file upload
            'file_path' => ['required', 'file', 'max:10240'], // 10MB

            // ✅ tags (many-to-many)
            'tags' => ['nullable', 'array'],
            'tags.*' => ['integer', 'exists:tags,id'],
        ];
    }
}
