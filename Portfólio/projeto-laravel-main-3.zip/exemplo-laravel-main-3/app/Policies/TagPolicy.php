<?php

namespace App\Policies;

use App\Models\Tag;
use App\Models\User;

class TagPolicy
{
    /**
     * Any authenticated user can list tags (adjust if needed).
     */
    public function viewAny(User $user): bool
    {
        return true;
    }

    /**
     * Tags are usually public-readable (SEO/content use case).
     */
    public function view(User $user, Tag $tag): bool
    {
        return true;
    }

    /**
     * Only admins can create tags.
     */
    public function create(User $user): bool
    {
        return $user->is_admin;
    }

    /**
     * Only admins can update tags.
     */
    public function update(User $user, Tag $tag): bool
    {
        return $user->is_admin;
    }

    /**
     * Only admins can delete tags.
     */
    public function delete(User $user, Tag $tag): bool
    {
        return $user->is_admin;
    }

    /**
     * Usually same rule as delete.
     */
    public function restore(User $user, Tag $tag): bool
    {
        return $user->is_admin;
    }

    /**
     * Hard delete should be even more restricted (often same as admin-only).
     */
    public function forceDelete(User $user, Tag $tag): bool
    {
        return $user->is_admin;
    }
}
