﻿using _003.POO3._03Data;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _003.POO3._02Control
{
    // permite controlar o fluxo e conteudo de dados
    internal class Controlo
    {
        // atributos
        public string mensagem = "";
        public bool operacao = false;
        public bool existe = false;

        // definição de métodos
        public bool verificaCaixasCredenciais(string ncartao, string npin)
        { 
            if(ncartao == "" || npin == "")
                mensagem = "Erro no preenchimento das credenciais / credencial vazia!";
            else
            {
                Login log = new Login();
                log.verificaCredenciaisBD(ncartao, npin);
                mensagem = log.mensagem;
                operacao = log.operacao;
                existe = log.existe;
            }           
            return operacao;
        }

        public bool ctrlVerificarCredenciaisRegisto(string ncartao, string npin1, string npin2)
        {
            if (ncartao == "" || npin1 == "" || npin2 == "")
                mensagem = "Erro no preenchimento das credenciais / credencial vazia!";
            else
                operacao = true;


         return operacao;

        }
    }
}
