﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _003.POO3
{
    public partial class Form2 : Form
    {
        // def do obj
        Multibanco multibanco = new Multibanco(500);
        int numberMoves = 0;

        public Form2()
        {

            InitializeComponent();

        }
        public Form2(string numCartao)
        {
            InitializeComponent();
            txtCartao.Text = numCartao;
            txtBallance.Text = Convert.ToString(multibanco.getSaldo());
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // saida da aplicação
            Application.Exit();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            lstView.View = View.Details;
            lstView.FullRowSelect = true;
            lstView.GridLines = true;

            lstView.Columns.Add("ID", 50);
            lstView.Columns.Add("TimeStamp", 250);
            lstView.Columns.Add("Tipo", 100);
            lstView.Columns.Add("Value", 200);
        }
        
        private void btnRaiseMoey_Click(object sender, EventArgs e)
        {
            if (!multibanco.pickUpMoney(Convert.ToInt16(txtvalue.Text)))
                MessageBox.Show("Dado inválidos", "Levantamento", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                txtBallance.Text = Convert.ToString(multibanco.getSaldo());
                movimentos("Levantamento", Convert.ToInt16(txtvalue.Text));

            }
        }

        private void txtvalue_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnStoreMoney_Click(object sender, EventArgs e)
        {
            if (!multibanco.storeMoney(Convert.ToInt16(txtvalue.Text)))
                MessageBox.Show("Dado inválidos", "Depósito", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                txtBallance.Text = Convert.ToString(multibanco.getSaldo());
                movimentos("Depósito", Convert.ToInt16(txtvalue.Text));
            }
        }
        // movimentos de depositos e de levanmentos
        public void movimentos(string tipo, int value)
        {
            numberMoves++;
            // def de timestamp
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:MM:ss");

            ListViewItem record = new ListViewItem(new[]
            {
                numberMoves.ToString(),
                timestamp,
                tipo,
                value.ToString()
            }
            );  
            lstView.Items.Add( record );

        }
    }

    // classe qu e gere objs de Multibanco
    public class Multibanco
    {
        // def atributos
        int saldo;
        string nomeConta;

        // construtores
        public Multibanco()
        {

        }
        public Multibanco(int newSaldo)
        {
            setSaldo(newSaldo);
        }

        // métodos acessores
        public void setNomeConta(string newNomeConta) { nomeConta = newNomeConta; }
        public void setSaldo(int saldo) { this.saldo = saldo; }
        public int getSaldo() { return saldo; }
        public string getNomeConta() { return nomeConta; }

        // métodos comuns
        public bool pickUpMoney(int valor)
        {
            bool flag = true;
            if (valor <= 0 || valor > saldo)
                flag = false;
            else
                saldo -= valor;

            return flag;
        }

        // metodo de deposito
        public bool storeMoney(int newValue)
        {
            bool flag = true;
            if (newValue > 0)
                saldo += newValue;
            else
                flag = false;
            return flag;
        }
    }



}
