﻿namespace _003.POO3._01Presentation
{
    partial class frmRegistar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnRegistar = new Button();
            btnExit = new Button();
            txtPIN1 = new TextBox();
            txtCartao = new TextBox();
            label1 = new Label();
            txtPin2 = new TextBox();
            SuspendLayout();
            // 
            // btnRegistar
            // 
            btnRegistar.Location = new Point(82, 356);
            btnRegistar.Name = "btnRegistar";
            btnRegistar.Size = new Size(155, 61);
            btnRegistar.TabIndex = 11;
            btnRegistar.Text = "Registar";
            btnRegistar.UseVisualStyleBackColor = true;
            btnRegistar.Click += btnRegistar_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(270, 356);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(155, 61);
            btnExit.TabIndex = 9;
            btnExit.Text = "Cancelar";
            btnExit.UseVisualStyleBackColor = true;
            // 
            // txtPIN1
            // 
            txtPIN1.Font = new Font("Segoe UI", 26F);
            txtPIN1.Location = new Point(104, 184);
            txtPIN1.Name = "txtPIN1";
            txtPIN1.PasswordChar = '*';
            txtPIN1.PlaceholderText = "PIN...";
            txtPIN1.Size = new Size(318, 65);
            txtPIN1.TabIndex = 8;
            // 
            // txtCartao
            // 
            txtCartao.Font = new Font("Segoe UI", 26F);
            txtCartao.Location = new Point(107, 113);
            txtCartao.Name = "txtCartao";
            txtCartao.PlaceholderText = "Card number...";
            txtCartao.Size = new Size(318, 65);
            txtCartao.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 50F, FontStyle.Bold);
            label1.ForeColor = SystemColors.ActiveCaption;
            label1.Location = new Point(158, -12);
            label1.Name = "label1";
            label1.Size = new Size(229, 112);
            label1.TabIndex = 6;
            label1.Text = "ATM";
            // 
            // txtPin2
            // 
            txtPin2.AcceptsReturn = true;
            txtPin2.Font = new Font("Segoe UI", 26F);
            txtPin2.Location = new Point(104, 255);
            txtPin2.Name = "txtPin2";
            txtPin2.PasswordChar = '*';
            txtPin2.PlaceholderText = "PIN...";
            txtPin2.Size = new Size(318, 65);
            txtPin2.TabIndex = 12;
            // 
            // frmRegistar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(561, 450);
            Controls.Add(txtPin2);
            Controls.Add(btnRegistar);
            Controls.Add(btnExit);
            Controls.Add(txtPIN1);
            Controls.Add(txtCartao);
            Controls.Add(label1);
            Name = "frmRegistar";
            Text = "frmRegistar";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnRegistar;
        private Button btnExit;
        private TextBox txtPIN1;
        private TextBox txtCartao;
        private Label label1;
        private TextBox txtPin2;
    }
}