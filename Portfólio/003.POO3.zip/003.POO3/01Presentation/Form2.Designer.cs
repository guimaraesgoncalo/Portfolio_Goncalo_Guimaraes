﻿namespace _003.POO3
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExit = new Button();
            txtBallance = new TextBox();
            label1 = new Label();
            lstView = new ListView();
            btnRaiseMoey = new Button();
            txtvalue = new TextBox();
            btnStoreMoney = new Button();
            txtCartao = new TextBox();
            SuspendLayout();
            // 
            // btnExit
            // 
            btnExit.Location = new Point(354, 377);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(155, 61);
            btnExit.TabIndex = 6;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // txtBallance
            // 
            txtBallance.Font = new Font("Segoe UI", 26F);
            txtBallance.Location = new Point(490, 47);
            txtBallance.Name = "txtBallance";
            txtBallance.Size = new Size(318, 65);
            txtBallance.TabIndex = 5;
            txtBallance.TextAlign = HorizontalAlignment.Center;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 50F, FontStyle.Bold);
            label1.ForeColor = SystemColors.ActiveCaption;
            label1.Location = new Point(255, 22);
            label1.Name = "label1";
            label1.Size = new Size(229, 112);
            label1.TabIndex = 4;
            label1.Text = "ATM";
            // 
            // lstView
            // 
            lstView.Location = new Point(255, 138);
            lstView.Name = "lstView";
            lstView.Size = new Size(553, 213);
            lstView.TabIndex = 7;
            lstView.UseCompatibleStateImageBehavior = false;
            // 
            // btnRaiseMoey
            // 
            btnRaiseMoey.Location = new Point(22, 138);
            btnRaiseMoey.Name = "btnRaiseMoey";
            btnRaiseMoey.Size = new Size(227, 61);
            btnRaiseMoey.TabIndex = 8;
            btnRaiseMoey.Text = "Pick-up Money";
            btnRaiseMoey.UseVisualStyleBackColor = true;
            btnRaiseMoey.Click += btnRaiseMoey_Click;
            // 
            // txtvalue
            // 
            txtvalue.Font = new Font("Segoe UI", 26F);
            txtvalue.Location = new Point(22, 205);
            txtvalue.Name = "txtvalue";
            txtvalue.Size = new Size(227, 65);
            txtvalue.TabIndex = 9;
            txtvalue.TextAlign = HorizontalAlignment.Center;
            txtvalue.TextChanged += txtvalue_TextChanged;
            // 
            // btnStoreMoney
            // 
            btnStoreMoney.Location = new Point(22, 276);
            btnStoreMoney.Name = "btnStoreMoney";
            btnStoreMoney.Size = new Size(227, 61);
            btnStoreMoney.TabIndex = 10;
            btnStoreMoney.Text = "Store Money";
            btnStoreMoney.UseVisualStyleBackColor = true;
            btnStoreMoney.Click += btnStoreMoney_Click;
            // 
            // txtCartao
            // 
            txtCartao.Font = new Font("Segoe UI", 26F);
            txtCartao.Location = new Point(22, 47);
            txtCartao.Name = "txtCartao";
            txtCartao.Size = new Size(227, 65);
            txtCartao.TabIndex = 11;
            txtCartao.TextAlign = HorizontalAlignment.Center;
            txtCartao.TextChanged += textBox1_TextChanged;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(839, 450);
            Controls.Add(txtCartao);
            Controls.Add(btnStoreMoney);
            Controls.Add(txtvalue);
            Controls.Add(btnRaiseMoey);
            Controls.Add(lstView);
            Controls.Add(btnExit);
            Controls.Add(txtBallance);
            Controls.Add(label1);
            Name = "Form2";
            Text = "ATM";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnExit;
        private TextBox txtBallance;
        private Label label1;
        private ListView lstView;
        private Button btnRaiseMoey;
        private TextBox txtvalue;
        private Button btnStoreMoney;
        private TextBox txtCartao;
    }
}