﻿using _003.POO3._02Control;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _003.POO3._01Presentation
{
    public partial class frmRegistar : Form
    {
        public string mensagem = "";
        public frmRegistar()
        {
            InitializeComponent();
        }

        private void btnRegistar_Click(object sender, EventArgs e)
        {
            // validar se existe o nCartão
            Controlo ctrl = new Controlo();
            ctrl.ctrlVerificarCredenciaisRegisto(txtCartao.Text, txtPIN1.Text, txtPin2.Text);
            if(ctrl.operacao == false)
            { 
                mensagem = ctrl.mensagem;
                MessageBox.Show(mensagem, "ERRO!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
