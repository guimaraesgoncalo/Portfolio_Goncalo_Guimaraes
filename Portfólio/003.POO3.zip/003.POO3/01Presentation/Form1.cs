using _003.POO3._01Presentation;
using _003.POO3._02Control;

namespace _003.POO3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // saida da ATM
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {   // teste das credenciais
            // instanciar objs de controlo
            Controlo ctrl = new Controlo();
            ctrl.verificaCaixasCredenciais(txtCartao.Text, txtPIN.Text);

            if (!ctrl.operacao)
                MessageBox.Show(ctrl.mensagem, "ERRO CREDENCIAIS", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                if (ctrl.existe)
                    MessageBox.Show(ctrl.mensagem, "CREDENCIAIS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show(ctrl.mensagem, "CREDENCIAIS INEXISTENTES", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnRegistar_Click(object sender, EventArgs e)
        {
            frmRegistar frmReg = new frmRegistar();
            frmReg.ShowDialog();
        }
    }
}
