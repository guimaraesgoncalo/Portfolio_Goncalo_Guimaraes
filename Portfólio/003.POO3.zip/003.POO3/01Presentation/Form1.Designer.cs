﻿namespace _003.POO3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtCartao = new TextBox();
            txtPIN = new TextBox();
            btnExit = new Button();
            btnLogin = new Button();
            btnRegistar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 50F, FontStyle.Bold);
            label1.ForeColor = SystemColors.ActiveCaption;
            label1.Location = new Point(156, 32);
            label1.Name = "label1";
            label1.Size = new Size(229, 112);
            label1.TabIndex = 0;
            label1.Text = "ATM";
            label1.Click += label1_Click;
            // 
            // txtCartao
            // 
            txtCartao.Font = new Font("Segoe UI", 26F);
            txtCartao.Location = new Point(105, 157);
            txtCartao.Name = "txtCartao";
            txtCartao.PlaceholderText = "Card number...";
            txtCartao.Size = new Size(318, 65);
            txtCartao.TabIndex = 1;
            // 
            // txtPIN
            // 
            txtPIN.Font = new Font("Segoe UI", 26F);
            txtPIN.Location = new Point(102, 228);
            txtPIN.Name = "txtPIN";
            txtPIN.PasswordChar = '*';
            txtPIN.PlaceholderText = "PIN...";
            txtPIN.Size = new Size(318, 65);
            txtPIN.TabIndex = 2;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(352, 313);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(155, 61);
            btnExit.TabIndex = 3;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // btnLogin
            // 
            btnLogin.Location = new Point(12, 313);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(155, 61);
            btnLogin.TabIndex = 4;
            btnLogin.Text = "Login";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnRegistar
            // 
            btnRegistar.Location = new Point(187, 313);
            btnRegistar.Name = "btnRegistar";
            btnRegistar.Size = new Size(155, 61);
            btnRegistar.TabIndex = 5;
            btnRegistar.Text = "Registar";
            btnRegistar.UseVisualStyleBackColor = true;
            btnRegistar.Click += btnRegistar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(519, 426);
            Controls.Add(btnRegistar);
            Controls.Add(btnLogin);
            Controls.Add(btnExit);
            Controls.Add(txtPIN);
            Controls.Add(txtCartao);
            Controls.Add(label1);
            Name = "Form1";
            Text = "ATM";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtCartao;
        private TextBox txtPIN;
        private Button btnExit;
        private Button btnLogin;
        private Button btnRegistar;
    }
}
