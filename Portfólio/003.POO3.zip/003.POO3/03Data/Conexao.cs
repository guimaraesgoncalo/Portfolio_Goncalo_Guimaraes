﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _003.POO3._03Data
{
    internal class Conexao
    {
        // classe de ligacao à BD + abrir e fechar a BD

        SqlConnection conn = new SqlConnection();

        public Conexao() 
        {
            conn.ConnectionString = @"Data Source=LAPTOP-MLPL9EVO;Initial Catalog=MMPOO2025;Integrated Security=True";
        }
        public SqlConnection connectar()
        {
            conn.Open();
            return conn;
        }
        public void desconectar()
        {
            conn.Close();
        }
    }
}
