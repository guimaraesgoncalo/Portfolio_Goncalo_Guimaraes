﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace _003.POO3._03Data
{
    internal class Login
    {
        // ligar a BD
        Conexao conexao = new Conexao();

        // declarar o atributo para duportar linhas de SQL
        SqlCommand cmd = new SqlCommand();

        // leitura de registos da tabela
        SqlDataReader dr;

        // mensagens do resultado do  acesso à tabela
        public string mensagem = "";
        public bool operacao = false;
        public bool existe = false;
            
        // metodo para averiguar se as credenciais  existe
        public bool verificaCredenciaisBD(string ncartao, string npin)
        {
            try
            {
                cmd.CommandText = "select * from tCredenciais where ncartao='" + ncartao + "' and npin='" + npin + "'";
                cmd.Connection = conexao.connectar();

                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    existe = true;
                    mensagem = "Credenciais válidas!";
                }
                else
                {
                    existe = false;
                    mensagem = "Credenciais inválidas!";
                }
                operacao = true;
                conexao.desconectar();
                dr.Close();
            }
            catch(SqlException erro)
            {
                mensagem = "ERRO: " + erro.ErrorCode + " - " + erro.Message;
                operacao= false;
            }
            return operacao;
        }
    }
}
